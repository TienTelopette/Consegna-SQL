-- 1. Verificare che i campi definiti come PK siano univoci. 

-- Verifica inserimento chiave primaria duplicata
insert into product values (1, 2, "Doll", 1);

-- Controllo presenza chiavi primarie duplicate
select
	count(*) DuplicatedPrimaryKeysCount
from
	product
group by
	productid
having
	DuplicatedPrimaryKeysCount > 1;

-- Verifica inserimento chiave primaria duplicata
insert into category values (1,"Puzzles");

-- Controllo presenza chiavi primarie duplicate
select
	count(*) DuplicatedPrimaryKeysCount
from
	category
group by
	categoryid
having
	DuplicatedPrimaryKeysCount > 1;

-- Verifica inserimento chiave primaria duplicata
insert into region values (1,"Middle East");

-- Controllo presenza chiavi primarie duplicate
select
	count(*) DuplicatedPrimaryKeysCount
from
	region
group by
	regionid
having
	DuplicatedPrimaryKeysCount > 1;

-- Verifica inserimento chiave primaria duplicata
insert into sale values (1,"2023-02-02",1,1,1);

-- Controllo presenza chiavi primarie duplicate
select
	count(*) DuplicatedPrimaryKeysCount
from
	sale
group by
	saleid
having
	DuplicatedPrimaryKeysCount > 1;


-- 2. Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno.  

select
	productname Product, year(orderdate) Year, sum(orderquantity * unitprice) TotalAmount
from
	sale join product
using
	(productid)
group by
	productname, year(orderdate);


-- 3. Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente.

select
	regionname RegionName, year(orderdate) Year, sum(unitprice*orderquantity) TotalAmount
from
	sale join product
using
	(productid)
join
	region
using
	(regionid)
group by
	regionname, year(orderdate)
order by
	year(orderdate), TotalAmount desc;
    
    
-- 4. Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato? 

select
	categoryname Category, sum(orderquantity * unitprice) TotalAmount
from
	product join sale
using
	(productid)
join
	category
using
	(categoryid)
group by
	categoryname
order by
	TotalAmount desc;


-- 5. Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti. 

-- Con una left join tra Product e Sale con condizione productid di Sale = null si trovano tutti i prodotti che non figurano
-- in nessuna transazione
select
	*
from
	product left join sale s
using
	(productid)
where
	s.productid is null;
    
    
-- Oppure possiamo fare una select dei prodotti con productid non presenti nell'insieme dei productid
-- presi da tutti i Sales

select
	ProductId, ProductName, UnitPrice
from
	product
where
	productid not in (	select
							distinct productid
						from
							sale);

    
-- 6. Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente).

select
	productname Product, date(max(orderdate)) MostRecentSale
from
	product join sale
using
	(productid)
group by
	productname