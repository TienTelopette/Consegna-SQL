CREATE DATABASE ToysGroup;
USE ToysGroup;

CREATE TABLE Category (
	CategoryId int primary key,
    CategoryName varchar(100)
);

CREATE TABLE Product (
	ProductId int primary key,
	UnitPrice decimal(4,2),
    ProductName varchar(50),
    CategoryId int,
    FOREIGN KEY (CategoryId) REFERENCES Category (CategoryId) on delete set null
);

CREATE TABLE Region (
	RegionId int primary key,
    RegionName varchar(50)
);

CREATE TABLE Sale (
	SaleId int primary key,
    OrderDate datetime,
    OrderQuantity int,
    RegionId int,
    ProductId int,
    FOREIGN KEY (RegionId) REFERENCES Region(RegionId) on delete cascade,
    FOREIGN KEY (ProductId) REFERENCES Product(ProductId) on delete cascade
);